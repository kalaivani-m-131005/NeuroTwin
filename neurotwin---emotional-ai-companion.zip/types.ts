
export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
  isError?: boolean;
}

export enum MoodState {
  NEUTRAL = 'NEUTRAL',
  LISTENING = 'LISTENING',
  THINKING = 'THINKING',
  SPEAKING = 'SPEAKING',
}

export interface NeuroConfig {
  voiceEnabled: boolean;
  languageDetected: string;
}

export interface VoiceSettings {
  voiceURI: string;
  rate: number;
  pitch: number;
}

export interface EmotionalAnalysis {
  intensity: number; // 0.0 to 1.0
  tips: string[];
}

export interface ChatSession {
  id: string;
  title: string;
  preview: string;
  timestamp: number;
  messages: Message[];
}
