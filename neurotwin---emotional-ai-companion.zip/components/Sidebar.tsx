
import React, { useState } from 'react';
import { Heart, Settings, Plus, MessageSquare, ChevronDown, ChevronUp, Mic2, Gauge, Volume2, LogIn, LogOut, User, Trash2 } from 'lucide-react';
import { VoiceSettings, ChatSession } from '../types';

interface SidebarProps {
  onNewChat: () => void;
  isOpen: boolean;
  toggleSidebar: () => void;
  availableVoices: SpeechSynthesisVoice[];
  voiceSettings: VoiceSettings;
  setVoiceSettings: React.Dispatch<React.SetStateAction<VoiceSettings>>;
  isLoggedIn: boolean;
  toggleLogin: () => void;
  chatSessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (session: ChatSession) => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  onNewChat, 
  isOpen, 
  toggleSidebar,
  availableVoices,
  voiceSettings,
  setVoiceSettings,
  isLoggedIn,
  toggleLogin,
  chatSessions,
  currentSessionId,
  onSelectSession,
  onDeleteSession
}) => {
  const [showPreferences, setShowPreferences] = useState(false);

  const formatTime = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = (now.getTime() - date.getTime()) / 1000; // seconds

    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-20 md:hidden backdrop-blur-sm"
          onClick={toggleSidebar}
        />
      )}

      {/* Sidebar Container */}
      <div className={`
        fixed inset-y-0 left-0 z-30 w-72 bg-neuro-card/95 backdrop-blur-xl border-r border-white/5 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:relative md:translate-x-0
        flex flex-col h-full shadow-2xl
      `}>
        {/* Logo / Header */}
        <div className="p-6 border-b border-white/5 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-neuro-primary to-neuro-secondary flex items-center justify-center text-white shadow-lg shadow-purple-500/20">
              <Heart size={16} fill="currentColor" />
            </div>
            <h1 className="text-xl font-bold bg-gradient-to-r from-neuro-primary to-neuro-secondary bg-clip-text text-transparent">
              NeuroTwin
            </h1>
          </div>
          <p className="text-xs text-neuro-muted mt-2 font-medium">Emotional AI Companion</p>
        </div>

        {/* Actions */}
        <div className="p-4 shrink-0 space-y-3">
          <button
            onClick={() => {
              onNewChat();
              if (window.innerWidth < 768) toggleSidebar();
            }}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-neuro-primary/20 to-neuro-secondary/20 hover:from-neuro-primary/30 hover:to-neuro-secondary/30 text-neuro-text py-3 rounded-xl border border-white/10 transition-all active:scale-95 shadow-inner"
          >
            <Plus size={18} />
            <span className="font-semibold text-sm">New Conversation</span>
          </button>
        </div>

        {/* Recent Chats List */}
        <div className="flex-1 overflow-y-auto px-4 py-2 custom-scrollbar">
          <h3 className="text-xs font-bold text-neuro-muted uppercase tracking-wider mb-3 px-2 flex justify-between items-center">
            <span>Recent Chats</span>
            <span className="text-[10px] opacity-50 bg-white/5 px-2 py-0.5 rounded-full">{chatSessions.length}</span>
          </h3>
          
          {isLoggedIn ? (
            <div className="space-y-1">
              {chatSessions.length === 0 ? (
                <div className="text-xs text-neuro-muted/50 text-center py-8 italic">
                  No conversations yet.
                </div>
              ) : (
                chatSessions.map((session) => (
                  <button
                    key={session.id}
                    onClick={() => onSelectSession(session)}
                    className={`
                      w-full text-left px-3 py-3 rounded-lg text-sm transition-all truncate flex items-start gap-3 group relative
                      ${currentSessionId === session.id 
                        ? 'bg-white/10 text-white' 
                        : 'text-neuro-muted hover:bg-white/5 hover:text-neuro-text'
                      }
                    `}
                  >
                    <MessageSquare size={14} className={`mt-1 shrink-0 ${currentSessionId === session.id ? 'text-neuro-accent' : 'opacity-50'}`} />
                    <div className="flex-1 overflow-hidden">
                       <div className="font-medium truncate">{session.title}</div>
                       <div className="text-[10px] opacity-60 truncate flex justify-between mt-1">
                         <span>{session.preview}</span>
                         <span className="shrink-0 ml-2">{formatTime(session.timestamp)}</span>
                       </div>
                    </div>
                    
                    {/* Delete Button (Visible on hover) */}
                    <div 
                      onClick={(e) => onDeleteSession(session.id, e)}
                      className="absolute right-2 top-3 p-1 text-neuro-muted hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity bg-neuro-card/80 rounded"
                      title="Delete chat"
                    >
                      <Trash2 size={12} />
                    </div>
                  </button>
                ))
              )}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8 px-4 border border-dashed border-white/10 rounded-xl bg-white/5">
              <p className="text-sm font-semibold text-neuro-text mb-1">History Paused</p>
              <p className="text-xs text-neuro-muted text-center mb-3">Log in to save and resume your conversations.</p>
              <button 
                onClick={toggleLogin}
                className="text-xs bg-neuro-card border border-white/10 px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors"
              >
                Log In Now
              </button>
            </div>
          )}
        </div>

        {/* Bottom Section */}
        <div className="border-t border-white/5 bg-black/20 shrink-0">
          
          {/* Voice Prefs */}
          <button 
            onClick={() => setShowPreferences(!showPreferences)}
            className="w-full flex items-center justify-between p-4 text-sm text-neuro-muted hover:text-neuro-text hover:bg-white/5 transition-colors border-b border-white/5"
          >
            <div className="flex items-center gap-3">
              <Settings size={18} />
              <span className="font-medium">Voice Preferences</span>
            </div>
            {showPreferences ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
          </button>

          {showPreferences && (
            <div className="px-4 py-4 space-y-4 bg-black/20 border-b border-white/5">
              {/* Voice Selector */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-xs text-neuro-muted uppercase font-bold tracking-wider">
                  <Mic2 size={12} /> Voice
                </label>
                <select
                  value={voiceSettings.voiceURI}
                  onChange={(e) => setVoiceSettings(prev => ({ ...prev, voiceURI: e.target.value }))}
                  className="w-full bg-neuro-bg border border-white/10 rounded-lg px-2 py-2 text-xs text-neuro-text focus:outline-none focus:border-neuro-primary"
                >
                  {availableVoices.map((voice) => (
                    <option key={voice.voiceURI} value={voice.voiceURI}>
                      {voice.name} ({voice.lang})
                    </option>
                  ))}
                </select>
              </div>

              {/* Speed Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-neuro-muted uppercase font-bold tracking-wider">
                  <label className="flex items-center gap-2"><Gauge size={12} /> Speed</label>
                  <span>{voiceSettings.rate}x</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={voiceSettings.rate}
                  onChange={(e) => setVoiceSettings(prev => ({ ...prev, rate: parseFloat(e.target.value) }))}
                  className="w-full h-1 bg-neuro-bg rounded-lg appearance-none cursor-pointer accent-neuro-primary"
                />
              </div>

              {/* Pitch Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-neuro-muted uppercase font-bold tracking-wider">
                  <label className="flex items-center gap-2"><Volume2 size={12} /> Pitch</label>
                  <span>{voiceSettings.pitch}</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={voiceSettings.pitch}
                  onChange={(e) => setVoiceSettings(prev => ({ ...prev, pitch: parseFloat(e.target.value) }))}
                  className="w-full h-1 bg-neuro-bg rounded-lg appearance-none cursor-pointer accent-neuro-secondary"
                />
              </div>
            </div>
          )}

          {/* User/Login */}
          <button 
            onClick={toggleLogin}
            className="w-full p-4 flex items-center gap-3 text-sm hover:bg-white/5 transition-colors text-neuro-muted hover:text-white"
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isLoggedIn ? 'bg-neuro-primary/20 text-neuro-primary' : 'bg-white/5'}`}>
              <User size={14} />
            </div>
            <div className="flex-1 text-left">
              <div className="font-medium">{isLoggedIn ? 'User Logged In' : 'Guest User'}</div>
              <div className="text-[10px] opacity-60">{isLoggedIn ? 'Saving history' : 'History paused'}</div>
            </div>
            {isLoggedIn ? <LogOut size={16} /> : <LogIn size={16} />}
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
