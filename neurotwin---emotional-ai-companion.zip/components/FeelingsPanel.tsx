import React from 'react';
import { ChevronDown, ChevronUp, ShieldAlert, Activity, Lock, EyeOff } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface FeelingsPanelProps {
  isVisible: boolean;
  toggleVisibility: () => void;
  intensity: number;
  tips: string[];
  isLoggedIn: boolean;
}

const FeelingsPanel: React.FC<FeelingsPanelProps> = ({
  isVisible,
  toggleVisibility,
  intensity,
  tips,
  isLoggedIn
}) => {
  // Color based on intensity
  const getIntensityColor = (level: number) => {
    if (level < 0.4) return 'bg-emerald-400';
    if (level < 0.7) return 'bg-yellow-400';
    return 'bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.6)]';
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 mb-2 z-10 relative">
      {/* Toggle Button */}
      <button
        onClick={toggleVisibility}
        className="w-full flex items-center justify-between p-3 bg-neuro-card/40 backdrop-blur-md border border-white/5 rounded-xl hover:bg-neuro-card/60 transition-all group"
      >
        <div className="flex items-center gap-2 text-sm font-medium text-neuro-muted group-hover:text-neuro-text transition-colors">
          <Activity size={16} className={intensity >= 0.6 ? 'text-red-400 animate-pulse' : 'text-neuro-accent'} />
          <span>View feelings & coping tips</span>
        </div>
        {isVisible ? <ChevronUp size={16} className="text-neuro-muted" /> : <ChevronDown size={16} className="text-neuro-muted" />}
      </button>

      {/* Expandable Content */}
      <AnimatePresence>
        {isVisible && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="mt-2 p-4 bg-neuro-card border border-white/10 rounded-xl shadow-inner space-y-4 relative overflow-hidden">
              
              {/* Background accent */}
              <div className={`absolute top-0 left-0 w-1 h-full ${getIntensityColor(intensity)}`}></div>

              {/* Intensity Meter */}
              <div>
                <div className="flex justify-between text-xs text-neuro-muted mb-2 uppercase tracking-wider font-bold">
                  <span>Emotional Intensity Detected</span>
                  <span className={intensity >= 0.6 ? 'text-red-400' : 'text-emerald-400'}>
                    {(intensity * 100).toFixed(0)}%
                  </span>
                </div>
                <div className="h-2 w-full bg-black/40 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${intensity * 100}%` }}
                    className={`h-full ${getIntensityColor(intensity)} transition-all duration-1000`}
                  />
                </div>
              </div>

              {/* Auth Gate / Content */}
              {!isLoggedIn ? (
                <div className="flex flex-col items-center justify-center py-6 text-center space-y-3 border-t border-white/5 mt-4 bg-black/20 rounded-lg">
                  <div className="p-3 bg-white/5 rounded-full">
                    <Lock size={20} className="text-neuro-muted" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-semibold text-neuro-text">Log in to view coping strategies</p>
                    <p className="text-xs text-neuro-muted max-w-xs mx-auto leading-relaxed">
                      For your privacy, detailed emotional history and personalized coping tips are only available when logged in.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 pt-2">
                  <h4 className="text-sm font-bold text-neuro-text flex items-center gap-2">
                    <ShieldAlert size={14} className="text-neuro-primary" />
                    Recommended Coping Tips
                  </h4>
                  
                  {tips.length > 0 ? (
                    <ul className="grid gap-2">
                      {tips.map((tip, idx) => (
                        <motion.li 
                          key={idx}
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.1 }}
                          className="text-sm text-neuro-muted bg-white/5 px-3 py-2 rounded-lg border-l-2 border-neuro-primary flex items-start gap-2"
                        >
                          <span className="mt-1 w-1 h-1 rounded-full bg-neuro-primary shrink-0" />
                          {tip}
                        </motion.li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-neuro-muted italic p-2 border border-white/5 rounded">
                      No specific high-intensity triggers detected. You are doing well. ✨
                    </p>
                  )}
                  
                  {/* Ephemeral Warning */}
                  <div className="mt-3 flex items-start gap-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded text-[10px] text-blue-200/70">
                    <EyeOff size={12} className="mt-0.5 shrink-0" />
                    <span>
                      <strong>Privacy Mode:</strong> These tips are ephemeral and will disappear in a few moments. We never display raw private logs.
                    </span>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FeelingsPanel;