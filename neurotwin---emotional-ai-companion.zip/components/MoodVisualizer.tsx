import React from 'react';
import { motion } from 'framer-motion';
import { MoodState } from '../types';

interface MoodVisualizerProps {
  mood: MoodState;
}

const MoodVisualizer: React.FC<MoodVisualizerProps> = ({ mood }) => {
  
  // Determine colors based on mood
  const getColors = () => {
    switch (mood) {
      case MoodState.LISTENING:
        return ['#2dd4bf', '#0ea5e9', '#6366f1']; // Teal/Blue/Indigo
      case MoodState.THINKING:
        return ['#f59e0b', '#ec4899', '#8b5cf6']; // Amber/Pink/Violet
      case MoodState.SPEAKING:
        return ['#ec4899', '#d946ef', '#a855f7']; // Pink/Fuchsia/Purple
      case MoodState.NEUTRAL:
      default:
        return ['#8b5cf6', '#6366f1', '#a855f7']; // Violet/Indigo/Purple
    }
  };

  const colors = getColors();

  return (
    <div className="relative w-48 h-48 flex items-center justify-center">
      {/* Outer Glow */}
      <div 
        className="absolute inset-0 blur-3xl opacity-30 transition-colors duration-1000"
        style={{ background: `radial-gradient(circle, ${colors[0]}, transparent)` }}
      ></div>

      {/* Main Blob */}
      <motion.div
        className="relative w-32 h-32 rounded-full filter blur-md opacity-80 mix-blend-screen"
        animate={{
          scale: mood === MoodState.SPEAKING ? [1, 1.2, 1] : [1, 1.1, 1],
          rotate: [0, 90, 180, 270, 360],
          borderRadius: [
            "60% 40% 30% 70% / 60% 30% 70% 40%",
            "30% 60% 70% 40% / 50% 60% 30% 60%",
            "60% 40% 30% 70% / 60% 30% 70% 40%"
          ]
        }}
        transition={{
          duration: mood === MoodState.SPEAKING ? 3 : 8,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          background: `linear-gradient(45deg, ${colors[0]}, ${colors[1]})`
        }}
      />

      {/* Secondary Blob for depth */}
      <motion.div
        className="absolute w-32 h-32 rounded-full filter blur-md opacity-60 mix-blend-screen"
        animate={{
          scale: mood === MoodState.THINKING ? [1.1, 0.9, 1.1] : [1.1, 1.2, 1.1],
          rotate: [360, 270, 180, 90, 0],
          x: [0, 20, -20, 0],
          y: [0, -20, 20, 0]
        }}
        transition={{
          duration: mood === MoodState.THINKING ? 2 : 10,
          repeat: Infinity,
          ease: "easeInOut"
        }}
        style={{
          background: `linear-gradient(to right, ${colors[1]}, ${colors[2]})`
        }}
      />
      
      {/* Status Text Overlay */}
      <div className="absolute -bottom-8 text-neuro-muted text-xs tracking-widest uppercase font-semibold">
        {mood === MoodState.NEUTRAL ? 'Online' : mood}
      </div>
    </div>
  );
};

export default MoodVisualizer;
