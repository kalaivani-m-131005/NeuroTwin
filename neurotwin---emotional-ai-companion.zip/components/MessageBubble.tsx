
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { ThumbsUp, ThumbsDown } from 'lucide-react';
import { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const [feedback, setFeedback] = useState<'up' | 'down' | null>(null);

  // Calculate animation physics based on message length
  // Short messages feel lighter/faster, long messages feel heavier/smoother
  const transitionConfig = useMemo(() => {
    const isLong = message.text.length > 60;
    return {
      type: "spring",
      damping: isLong ? 25 : 15, // Higher damping = less bounce for long text
      stiffness: isLong ? 120 : 180, // Higher stiffness = snappier for short text
      mass: 1,
      opacity: { duration: 0.4 } // Linear fade for opacity
    };
  }, [message.text.length]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={transitionConfig}
      className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} group mb-4`}
    >
      <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-[85%] md:max-w-[70%]`}>
        <div
          className={`px-5 py-3 rounded-2xl shadow-lg backdrop-blur-sm text-sm md:text-base leading-relaxed
            ${isUser 
              ? 'bg-gradient-to-br from-neuro-secondary to-purple-600 text-white rounded-br-none' 
              : 'bg-neuro-card text-neuro-text border border-white/5 rounded-bl-none'
            }
            ${message.isError ? 'border-red-500 border bg-red-900/20' : ''}
          `}
        >
          <div className="whitespace-pre-wrap">{message.text}</div>
        </div>
        
        <div className="flex items-center gap-3 mt-1.5 px-1 min-h-[20px]">
          <span className="text-[10px] text-neuro-muted font-medium opacity-70">
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>

          {!isUser && !message.isError && (
            <div className="flex items-center gap-2 opacity-50 group-hover:opacity-100 transition-opacity duration-200">
              <button 
                onClick={() => setFeedback(feedback === 'up' ? null : 'up')}
                className={`p-1.5 rounded-full hover:bg-white/10 transition-colors ${feedback === 'up' ? 'text-neuro-accent bg-white/5' : 'text-neuro-muted hover:text-neuro-accent'}`}
                title="Helpful"
                aria-label="Thumbs up"
              >
                <ThumbsUp size={14} />
              </button>
              <button 
                onClick={() => setFeedback(feedback === 'down' ? null : 'down')}
                className={`p-1.5 rounded-full hover:bg-white/10 transition-colors ${feedback === 'down' ? 'text-red-400 bg-white/5' : 'text-neuro-muted hover:text-red-400'}`}
                title="Not helpful"
                aria-label="Thumbs down"
              >
                <ThumbsDown size={14} />
              </button>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default MessageBubble;
