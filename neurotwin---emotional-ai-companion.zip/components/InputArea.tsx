
import React, { useState, useRef, useEffect } from 'react';
import { Mic, Send, StopCircle, Loader2, XCircle, AlertCircle } from 'lucide-react';
import { MoodState } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface InputAreaProps {
  onSendMessage: (text: string) => void;
  isLoading: boolean;
  setMood: (mood: MoodState) => void;
}

const MAX_CHARS = 500;

const InputArea: React.FC<InputAreaProps> = ({ onSendMessage, isLoading, setMood }) => {
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // Auto-dismiss error toast after 5 seconds
  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => setErrorMessage(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);

  useEffect(() => {
    // Check browser support for Web Speech API
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      
      recognition.continuous = false; // Stop listening automatically when the user stops speaking
      recognition.interimResults = true; // Show text while the user is still speaking
      recognition.lang = navigator.language || 'en-US'; // Default to browser language

      recognition.onstart = () => {
        setIsListening(true);
        setMood(MoodState.LISTENING);
        setErrorMessage(null); // Clear previous errors
      };

      recognition.onend = () => {
        setIsListening(false);
        // Only reset mood if it was in LISTENING state (avoids overriding SPEAKING/THINKING if triggered elsewhere)
        setMood((prev) => prev === MoodState.LISTENING ? MoodState.NEUTRAL : prev);
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        // Enforce max length on voice input too
        if (transcript.length > MAX_CHARS) {
           transcript = transcript.substring(0, MAX_CHARS);
        }
        setInputText(transcript);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error", event.error);
        
        // Ignore 'aborted' as it often happens on manual stop
        if (event.error === 'aborted') {
          setIsListening(false);
          return;
        }

        setIsListening(false);
        setMood(MoodState.NEUTRAL);
        
        let msg = "Microphone error occurred.";
        switch (event.error) {
          case 'not-allowed':
            msg = "Microphone access denied. Please check your browser permissions.";
            break;
          case 'no-speech':
            msg = "No speech detected. Please speak closer to the mic.";
            break;
          case 'network':
            msg = "Network error. Voice input requires an internet connection.";
            break;
          case 'audio-capture':
            msg = "No microphone found. Please check your device settings.";
            break;
          case 'service-not-allowed':
             msg = "Voice recognition service not allowed by browser.";
             break;
          default:
             msg = "An error occurred with voice recognition.";
        }
        
        setErrorMessage(msg);
      };
      
      recognitionRef.current = recognition;
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }
    };
  }, [setMood]);

  const handleSend = () => {
    if (inputText.trim() && !isLoading) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const toggleVoice = () => {
    if (!recognitionRef.current) {
      setErrorMessage("Voice input is not supported in this browser.");
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      setInputText('');
      setErrorMessage(null);
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.error("Failed to start recognition", e);
        setErrorMessage("Could not start microphone.");
      }
    }
  };

  const getCharCountColor = () => {
    const count = inputText.length;
    if (count >= MAX_CHARS) return 'text-red-500 font-bold';
    if (count > MAX_CHARS * 0.9) return 'text-orange-400 font-medium';
    return 'text-neuro-muted/40';
  };

  return (
    <div className="w-full max-w-3xl mx-auto px-4 pb-6 pt-2 bg-gradient-to-t from-neuro-bg via-neuro-bg to-transparent relative">
      
      {/* Error Toast Notification */}
      <AnimatePresence>
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="absolute -top-24 left-0 right-0 mx-auto w-fit max-w-[90%] z-50 flex items-center gap-3 bg-red-500/90 text-white text-xs font-medium px-4 py-3 rounded-xl shadow-xl backdrop-blur-md border border-red-400/50"
          >
            <AlertCircle size={18} className="shrink-0 animate-pulse" />
            <span>{errorMessage}</span>
            <button 
              onClick={() => setErrorMessage(null)} 
              className="ml-2 hover:bg-white/20 rounded-full p-1 transition-colors"
              aria-label="Dismiss error"
            >
               <XCircle size={14} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Listening Status Indicator */}
      <AnimatePresence>
        {isListening && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="flex justify-center mb-2 overflow-hidden"
          >
             <span className="text-xs text-neuro-accent font-semibold tracking-widest uppercase animate-pulse flex items-center gap-2">
               <span className="w-2 h-2 bg-neuro-accent rounded-full animate-ping" />
               Listening...
             </span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className={`
        relative flex items-center gap-2 p-2 
        bg-neuro-card/80 backdrop-blur-md border 
        rounded-full transition-all duration-300
        ${isListening 
          ? 'border-neuro-accent shadow-[0_0_15px_rgba(45,212,191,0.2)]' 
          : 'border-white/10 shadow-2xl'
        }
      `}>
        
        {/* Voice Button */}
        <button
          onClick={toggleVoice}
          disabled={isLoading}
          className={`
            p-3 rounded-full transition-all duration-300 flex items-center justify-center
            ${isListening 
              ? 'bg-red-500/10 text-red-400 animate-pulse ring-1 ring-red-500/30' 
              : 'hover:bg-white/5 text-neuro-accent'
            }
          `}
          title={isListening ? "Stop Listening" : "Speak to NeuroTwin"}
        >
          {isListening ? <StopCircle size={24} /> : <Mic size={24} />}
        </button>

        {/* Text Input */}
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isListening ? "Listening..." : "Type a message..."}
          disabled={isLoading || isListening}
          maxLength={MAX_CHARS}
          className="flex-1 bg-transparent border-none focus:ring-0 text-neuro-text placeholder-neuro-muted/50 px-2 py-2 outline-none"
          autoFocus
        />

        {/* Character Counter */}
        <div className={`text-[10px] transition-colors duration-300 px-1 select-none ${getCharCountColor()}`}>
          {inputText.length}/{MAX_CHARS}
        </div>

        {/* Send Button */}
        <button
          onClick={handleSend}
          disabled={!inputText.trim() || isLoading}
          className={`
            p-3 rounded-full transition-all duration-300 flex items-center justify-center
            ${inputText.trim() && !isLoading
              ? 'bg-neuro-primary text-white shadow-lg shadow-neuro-primary/30 hover:scale-105 transform'
              : 'bg-white/5 text-white/20 cursor-not-allowed'
            }
          `}
        >
          {isLoading ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
        </button>
      </div>
    </div>
  );
};

export default InputArea;
