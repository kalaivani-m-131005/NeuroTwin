import React, { useRef, useEffect } from 'react';
import { Message, MoodState } from '../types';
import MessageBubble from './MessageBubble';
import MoodVisualizer from './MoodVisualizer';

interface ChatWindowProps {
  messages: Message[];
  mood: MoodState;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, mood }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, mood]);

  return (
    <div className="flex-1 overflow-y-auto px-4 pt-6 pb-4 scroll-smooth">
      <div className="max-w-3xl mx-auto flex flex-col min-h-full">
        
        {/* Empty State / Welcome */}
        {messages.length === 0 && (
          <div className="flex-1 flex flex-col items-center justify-center min-h-[50vh] space-y-8">
            <MoodVisualizer mood={mood} />
            <div className="text-center space-y-2 animate-fade-in">
              <h2 className="text-2xl font-bold text-white">Hello, friend.</h2>
              <p className="text-neuro-muted max-w-md mx-auto">
                I'm NeuroTwin. I speak English, Tamil, and Tanglish. Tell me, how are you feeling today?
              </p>
            </div>
          </div>
        )}

        {/* Message List */}
        <div className="flex-1 space-y-6">
          {messages.map((msg) => (
            <MessageBubble key={msg.id} message={msg} />
          ))}

          {/* Typing Indicator / Thinking State */}
          {mood === MoodState.THINKING && (
            <div className="flex justify-start mb-4">
               <div className="bg-neuro-card border border-white/5 px-5 py-4 rounded-2xl rounded-bl-none flex items-center gap-1.5 shadow-lg">
                 <div className="w-2 h-2 rounded-full bg-neuro-secondary animate-bounce" style={{ animationDelay: '0s' }}></div>
                 <div className="w-2 h-2 rounded-full bg-neuro-secondary animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                 <div className="w-2 h-2 rounded-full bg-neuro-secondary animate-bounce" style={{ animationDelay: '0.4s' }}></div>
               </div>
            </div>
          )}
        </div>

        <div ref={bottomRef} className="h-4" />
      </div>
    </div>
  );
};

export default ChatWindow;
