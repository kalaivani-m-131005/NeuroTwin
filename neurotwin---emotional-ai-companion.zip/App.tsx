
import React, { useState, useEffect } from 'react';
import { Menu, ShieldAlert, AlertTriangle } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import InputArea from './components/InputArea';
import FeelingsPanel from './components/FeelingsPanel';
import { initializeChat, sendMessageToNeuroTwin } from './services/geminiService';
import { Message, MoodState, VoiceSettings, ChatSession } from './types';
import { WELCOME_MESSAGE } from './constants';

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [mood, setMood] = useState<MoodState>(MoodState.NEUTRAL);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  
  // Auth State
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Emotional Intelligence State
  const [emotionalIntensity, setEmotionalIntensity] = useState(0.2);
  const [copingTips, setCopingTips] = useState<string[]>([]);
  const [showFeelingsPanel, setShowFeelingsPanel] = useState(false);
  const [hasAutoRevealed, setHasAutoRevealed] = useState(false);
  const [showHighIntensityModal, setShowHighIntensityModal] = useState(false);

  // Chat History State
  const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [storageError, setStorageError] = useState<string | null>(null);

  // Voice Settings State
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    voiceURI: '',
    rate: 1.0,
    pitch: 1.0
  });

  // Initialization
  useEffect(() => {
    const init = async () => {
      try {
        await initializeChat();
      } catch (e) {
        console.error("Failed to init chat", e);
      } finally {
        setIsInitializing(false);
      }
    };
    init();

    // Load available voices
    const loadVoices = () => {
      const available = window.speechSynthesis.getVoices();
      setVoices(available);
      
      // Set a default voice if none selected
      if (available.length > 0) {
        setVoiceSettings(prev => {
          if (prev.voiceURI) return prev; // Keep existing selection if any
          
          // Try to find a good default
          const preferred = available.find(v => 
            (v.name.includes('Google') && v.lang.startsWith('en')) || 
            v.name.includes('Samantha') ||
            v.name.includes('Female')
          ) || available[0];
          
          return { ...prev, voiceURI: preferred.voiceURI };
        });
      }
    };

    loadVoices();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }

    // Load Chat History from LocalStorage
    try {
      const savedSessions = localStorage.getItem('neurotwin_sessions');
      if (savedSessions) {
        const parsed: ChatSession[] = JSON.parse(savedSessions);
        // Revive Date objects in messages
        const revived = parsed.map(session => ({
          ...session,
          messages: session.messages.map(msg => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }))
        }));
        setChatSessions(revived);
      }
    } catch (e) {
      console.error("Failed to parse chat history", e);
      setStorageError("Failed to load history. Data may be corrupted.");
    }
  }, []);

  // Persist sessions whenever they change
  useEffect(() => {
    if (chatSessions.length > 0) {
      try {
        localStorage.setItem('neurotwin_sessions', JSON.stringify(chatSessions));
      } catch (e) {
        console.error("Failed to save chat history", e);
        setStorageError("Could not save history. Storage might be full.");
      }
    }
  }, [chatSessions]);

  // Auto-dismiss storage error
  useEffect(() => {
    if (storageError) {
      const timer = setTimeout(() => setStorageError(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [storageError]);

  const analyzeAndSetEmotion = (text: string) => {
    // Simulation: Calculate emotional intensity based on keywords
    const stressTriggers = ['anxious', 'scared', 'panic', 'help', 'overwhelmed', 'stress', 'afraid', 'terrified', 'sad', 'depressed', 'hurt', 'pain', 'die', 'kill', 'suicide'];
    const hits = stressTriggers.filter(t => text.toLowerCase().includes(t));
    
    let newIntensity = 0.2;
    let newTips: string[] = [];
    
    // Basic Mock Logic for Demo
    if (hits.length > 0) {
        // High Intensity detected
        newIntensity = 0.75 + (Math.random() * 0.2); // Random between 0.75 - 0.95
        newTips = [
            "Breathe deeply: Inhale for 4s, Hold for 4s, Exhale for 4s.",
            "Grounding: Find 5 things you can see and 4 things you can touch.",
            "Step away from the screen for a moment if you need to.",
            "Remember: This feeling is temporary and will pass."
        ];
    } else {
        // Neutral/Low
        newIntensity = 0.2 + (Math.random() * 0.2);
        newTips = [
            "Stay hydrated.",
            "Take a gentle stretch.",
            "Listen to some calming music."
        ];
    }

    setEmotionalIntensity(newIntensity);
    setCopingTips(newTips);

    // Rule: Auto-expand if >= 0.6 (High Intensity)
    // Rule: Only once per session per trigger
    if (newIntensity >= 0.6 && !hasAutoRevealed) {
        setShowFeelingsPanel(true);
        setShowHighIntensityModal(true); // Brief Modal
        setHasAutoRevealed(true);

        // Rule: Ephemeral tips (hide panel after 20s)
        const panelTimer = setTimeout(() => {
             setShowFeelingsPanel(false);
        }, 20000);

        // Rule: Brief Modal (hide modal after 4s)
        const modalTimer = setTimeout(() => {
            setShowHighIntensityModal(false);
        }, 4000);
        
        return () => { clearTimeout(panelTimer); clearTimeout(modalTimer); };
    }
  };

  const updateSession = (sessionId: string, newMessages: Message[], titleHint?: string) => {
    setChatSessions(prev => {
      const existingIdx = prev.findIndex(s => s.id === sessionId);
      const now = Date.now();
      const lastMsg = newMessages[newMessages.length - 1];
      const previewText = lastMsg ? (lastMsg.text.substring(0, 45) + (lastMsg.text.length > 45 ? '...' : '')) : 'New Conversation';
      
      const updatedSession: ChatSession = {
        id: sessionId,
        title: titleHint || (existingIdx >= 0 ? prev[existingIdx].title : 'New Conversation'),
        preview: previewText,
        timestamp: now,
        messages: newMessages
      };

      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx] = updatedSession;
        return copy.sort((a, b) => b.timestamp - a.timestamp);
      } else {
        return [updatedSession, ...prev];
      }
    });
  };

  const handleSendMessage = async (text: string) => {
    // 1. Prepare User Message
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: text,
      timestamp: new Date()
    };

    // 2. Determine Session ID
    let activeSessionId = currentSessionId;
    let isNewSession = false;
    if (!activeSessionId) {
      activeSessionId = Date.now().toString();
      setCurrentSessionId(activeSessionId);
      isNewSession = true;
    }

    // 3. Update Messages State
    const updatedMessages = [...messages, userMsg];
    setMessages(updatedMessages);
    setMood(MoodState.THINKING);

    // 4. Update History immediately (User message)
    const title = isNewSession ? (text.substring(0, 30) + (text.length > 30 ? '...' : '')) : undefined;
    updateSession(activeSessionId, updatedMessages, title);

    // 5. Analyze Emotion
    analyzeAndSetEmotion(text);

    try {
      // 6. Get AI Response
      const responseText = await sendMessageToNeuroTwin(text);
      
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText,
        timestamp: new Date()
      };

      setMood(MoodState.SPEAKING);
      
      // 7. Update Messages State with AI response
      const finalMessages = [...updatedMessages, aiMsg];
      setMessages(finalMessages);
      
      // 8. Update History with AI response
      updateSession(activeSessionId, finalMessages);
      
      speakResponse(responseText);

      const duration = (responseText.length * 100) / voiceSettings.rate;
      setTimeout(() => {
        setMood(prev => prev === MoodState.SPEAKING ? MoodState.NEUTRAL : prev);
      }, Math.min(duration, 15000));

    } catch (error) {
      const errorMsg: Message = {
        id: Date.now().toString(),
        role: 'model',
        text: "I'm having a little trouble connecting right now. Can we try again?",
        timestamp: new Date(),
        isError: true
      };
      const errorMessages = [...updatedMessages, errorMsg];
      setMessages(errorMessages);
      updateSession(activeSessionId, errorMessages);
      setMood(MoodState.NEUTRAL);
    }
  };

  const speakResponse = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel(); 
      const utterance = new SpeechSynthesisUtterance(text);
      
      const selectedVoice = voices.find(v => v.voiceURI === voiceSettings.voiceURI);
      if (selectedVoice) utterance.voice = selectedVoice;
      
      utterance.pitch = voiceSettings.pitch;
      utterance.rate = voiceSettings.rate;
      
      utterance.onend = () => setMood(prev => prev === MoodState.SPEAKING ? MoodState.NEUTRAL : prev);
      utterance.onerror = () => setMood(prev => prev === MoodState.SPEAKING ? MoodState.NEUTRAL : prev);

      window.speechSynthesis.speak(utterance);
    }
  };

  const handleNewChat = async () => {
    setMessages([]);
    setCurrentSessionId(null);
    setMood(MoodState.NEUTRAL);
    setHasAutoRevealed(false);
    setEmotionalIntensity(0.2);
    window.speechSynthesis.cancel();
    await initializeChat(); 
  };

  const loadSession = (session: ChatSession) => {
    setCurrentSessionId(session.id);
    setMessages(session.messages);
    setMood(MoodState.NEUTRAL);
    setEmotionalIntensity(0.2); // Reset analysis for old chat context
    if (window.innerWidth < 768) setSidebarOpen(false);
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setChatSessions(prev => prev.filter(s => s.id !== id));
    if (currentSessionId === id) {
       handleNewChat();
    }
  };

  return (
    <div className="flex h-screen w-full bg-neuro-bg text-neuro-text font-sans overflow-hidden">
      
      <Sidebar 
        isOpen={sidebarOpen} 
        toggleSidebar={() => setSidebarOpen(!sidebarOpen)} 
        onNewChat={handleNewChat}
        availableVoices={voices}
        voiceSettings={voiceSettings}
        setVoiceSettings={setVoiceSettings}
        isLoggedIn={isLoggedIn}
        toggleLogin={() => setIsLoggedIn(!isLoggedIn)}
        chatSessions={chatSessions}
        currentSessionId={currentSessionId}
        onSelectSession={loadSession}
        onDeleteSession={handleDeleteSession}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full relative">
        
        {/* Header */}
        <div className="h-16 border-b border-white/5 flex items-center justify-between px-4 md:px-6 bg-neuro-bg/50 backdrop-blur-sm z-10">
          <div className="flex items-center gap-3 md:hidden">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="p-2 -ml-2 text-neuro-muted hover:text-white"
            >
              <Menu size={24} />
            </button>
            <span className="font-bold text-lg bg-gradient-to-r from-neuro-primary to-neuro-secondary bg-clip-text text-transparent">
              NeuroTwin
            </span>
          </div>
          
          <div className="hidden md:flex items-center gap-2 text-sm text-neuro-muted">
             <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
             Connected
          </div>
        </div>

        {/* High Intensity Modal (Brief) */}
        <AnimatePresence>
          {showHighIntensityModal && (
            <motion.div
               initial={{ opacity: 0, y: -20 }}
               animate={{ opacity: 1, y: 0 }}
               exit={{ opacity: 0, y: -20 }}
               className="absolute top-20 left-0 right-0 mx-auto w-[90%] max-w-md z-50 bg-red-500/90 text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-3 border border-red-400/50 backdrop-blur-lg"
            >
               <ShieldAlert size={24} className="animate-pulse" />
               <div>
                 <h4 className="font-bold text-sm">High Emotional Intensity Detected</h4>
                 <p className="text-xs opacity-90">Auto-expanding coping tips for support.</p>
               </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Storage Error Toast */}
        <AnimatePresence>
          {storageError && (
             <motion.div
               initial={{ opacity: 0, x: 50 }}
               animate={{ opacity: 1, x: 0 }}
               exit={{ opacity: 0, x: 50 }}
               className="absolute top-20 right-4 md:right-8 z-50 bg-amber-900/80 border border-amber-500/30 text-amber-100 px-4 py-3 rounded-lg shadow-xl backdrop-blur-md flex items-center gap-3 max-w-xs md:max-w-sm"
             >
                <AlertTriangle size={18} className="text-amber-400 shrink-0" />
                <span className="text-xs font-medium">{storageError}</span>
             </motion.div>
          )}
        </AnimatePresence>

        {/* Feelings Panel (Hidden by default, expands on request or high intensity) */}
        <div className="mt-2">
            <FeelingsPanel 
                isVisible={showFeelingsPanel} 
                toggleVisibility={() => setShowFeelingsPanel(!showFeelingsPanel)}
                intensity={emotionalIntensity}
                tips={copingTips}
                isLoggedIn={isLoggedIn}
            />
        </div>

        {/* Chat Area */}
        <ChatWindow messages={messages} mood={mood} />

        {/* Input Area */}
        <InputArea 
          onSendMessage={handleSendMessage} 
          isLoading={mood === MoodState.THINKING}
          setMood={setMood}
        />

      </div>
    </div>
  );
}

export default App;
