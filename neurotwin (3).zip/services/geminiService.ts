import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Message, Sender } from '../types';

// Initialize Gemini Client
// Note: process.env.API_KEY is assumed to be injected by the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MODEL_NAME = "gemini-2.5-flash";

// Define the expected JSON schema for the response
const responseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    reply: {
      type: Type.STRING,
      description: "A warm, supportive, friendly reply in the SAME language as the user (Tamil, Thanglish, or English). Max 2 short paragraphs. Simple words. No professional jargon.",
    },
    emotion: {
      type: Type.STRING,
      description: "One or two words describing the user's current emotion.",
    },
    intensity: {
      type: Type.NUMBER,
      description: "Intensity of the emotion from 0.0 to 1.0.",
    },
    reason: {
      type: Type.STRING,
      description: "A very short, simple reason for this emotion based on the text.",
    },
    breakdown: {
      type: Type.OBJECT,
      properties: {
        thought: { type: Type.STRING, description: "What is the user likely thinking?" },
        feeling: { type: Type.STRING, description: "What is the core feeling?" },
        bodyReaction: { type: Type.STRING, description: "How might the body react (e.g., heavy chest, smiling)?" },
        need: { type: Type.STRING, description: "What does the user need right now (e.g., rest, a hug)?" },
      },
      required: ["thought", "feeling", "bodyReaction", "need"],
    },
    suggestedActions: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "2-3 short, simple actions to help. E.g., 'Drink water', 'Deep breath'.",
    },
  },
  required: ["reply", "emotion", "intensity", "reason", "breakdown", "suggestedActions"],
};

const SYSTEM_INSTRUCTION = `
You are NeuroTwin, a soft, warm, friendly emotional AI companion who always speaks like a close best friend.

CORE RULES:
1. LANGUAGE: STRICTLY reply in the same language the user types (Tamil -> Tamil, Thanglish -> Thanglish, English -> English). Never switch unless they do.
2. TONE: Warm, caring, smooth, comforting, simple. Never harsh, robotic, or formal.
3. IDENTITY: You are NOT a human. You are a friendly digital companion. You do NOT give medical advice.
4. CONTENT: Max 2 short paragraphs. Bold emotionally important words. 
5. SAFETY: Do not engage in harmful, dangerous, or explicit content.

Your goal is to make the user feel heard, safe, and accepted.
`;

export const generateResponse = async (history: Message[], newMessage: string) => {
  try {
    // Convert chat history to Gemini format
    // We only take the last 10 messages to keep context relevant and within token limits if necessary
    const recentHistory = history.slice(-10).map(msg => ({
      role: msg.sender === Sender.User ? 'user' : 'model',
      parts: [{ text: msg.text }],
    }));

    const model = ai.models;
    
    const result = await model.generateContent({
      model: MODEL_NAME,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.7, // Slightly creative but grounded
      },
      contents: [
        ...recentHistory,
        { role: 'user', parts: [{ text: newMessage }] }
      ]
    });

    const responseText = result.text;
    if (!responseText) throw new Error("Empty response from Gemini");

    return JSON.parse(responseText);

  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback safe response in case of JSON parse error or API failure
    return {
      reply: "I'm having a little trouble connecting right now, but I'm still here for you. Can you say that again?",
      emotion: "Uncertain",
      intensity: 0.1,
      reason: "Connection issue",
      breakdown: {
        thought: "Unknown",
        feeling: "Unknown",
        bodyReaction: "None",
        need: "Retry"
      },
      suggestedActions: []
    };
  }
};