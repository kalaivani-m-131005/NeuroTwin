export enum Sender {
  User = 'user',
  AI = 'ai'
}

export interface Breakdown {
  thought: string;
  feeling: string;
  bodyReaction: string;
  need: string;
}

export interface Analysis {
  emotion: string;
  intensity: number; // 0 to 1
  reason: string;
  breakdown: Breakdown;
  suggestedActions: string[];
}

export interface Message {
  id: string;
  sender: Sender;
  text: string;
  timestamp: number;
  analysis?: Analysis; // Only AI messages have analysis
  isBookmarked?: boolean;
}

export interface UserProfile {
  name: string;
  email: string;
  joinedAt: string;
  moodLogs: { date: string; emotion: string; intensity: number }[];
  chatHistory: Message[];
}

export enum View {
  Login = 'login',
  Signup = 'signup',
  Chat = 'chat',
  Profile = 'profile'
}

export interface AuthState {
  isLoggedIn: boolean;
  user: UserProfile | null;
}