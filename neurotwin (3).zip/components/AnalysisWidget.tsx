import React, { useState, useEffect } from 'react';
import { Analysis } from '../types';
import { ChevronDown, ChevronUp, Activity, Brain, Heart, Zap } from 'lucide-react';

interface AnalysisWidgetProps {
  analysis: Analysis;
}

export const AnalysisWidget: React.FC<AnalysisWidgetProps> = ({ analysis }) => {
  const [isOpen, setIsOpen] = useState(false);

  // Auto-open if intensity is high
  useEffect(() => {
    if (analysis.intensity >= 0.6) {
      setIsOpen(true);
    } else {
      setIsOpen(false);
    }
  }, [analysis]);

  const intensityPercent = Math.round(analysis.intensity * 100);
  const intensityColor = intensityPercent > 70 ? 'text-red-500' : intensityPercent > 40 ? 'text-orange-500' : 'text-green-500';
  const barColor = intensityPercent > 70 ? 'bg-red-400' : intensityPercent > 40 ? 'bg-orange-400' : 'bg-green-400';

  return (
    <div className="bg-white/80 backdrop-blur-sm border border-slate-200 rounded-2xl overflow-hidden mt-3 shadow-sm transition-all duration-300">
      {/* Header - Always visible */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-3 px-4 hover:bg-slate-50 transition-colors text-left"
      >
        <div className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Emotional Check-in</span>
            <div className="flex items-center gap-2">
              <span className="text-slate-800 font-medium capitalize">{analysis.emotion}</span>
              <span className={`text-xs font-bold ${intensityColor}`}>• {intensityPercent}%</span>
            </div>
          </div>
        </div>
        {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
      </button>

      {/* Expanded Content */}
      {isOpen && (
        <div className="p-4 pt-0 border-t border-slate-100 bg-slate-50/50">
           <div className="mt-3 w-full bg-slate-200 rounded-full h-1.5 mb-4">
              <div className={`h-1.5 rounded-full ${barColor}`} style={{ width: `${intensityPercent}%` }}></div>
           </div>

           <p className="text-sm text-slate-600 italic mb-4">"{analysis.reason}"</p>

           <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-2 mb-1">
                   <Brain className="w-3.5 h-3.5 text-neuro-500" />
                   <span className="text-xs font-semibold text-slate-500">Thought</span>
                </div>
                <p className="text-sm text-slate-700">{analysis.breakdown.thought}</p>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-2 mb-1">
                   <Heart className="w-3.5 h-3.5 text-rose-500" />
                   <span className="text-xs font-semibold text-slate-500">Feeling</span>
                </div>
                <p className="text-sm text-slate-700">{analysis.breakdown.feeling}</p>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-2 mb-1">
                   <Activity className="w-3.5 h-3.5 text-amber-500" />
                   <span className="text-xs font-semibold text-slate-500">Body</span>
                </div>
                <p className="text-sm text-slate-700">{analysis.breakdown.bodyReaction}</p>
              </div>

              <div className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-2 mb-1">
                   <Zap className="w-3.5 h-3.5 text-purple-500" />
                   <span className="text-xs font-semibold text-slate-500">Need</span>
                </div>
                <p className="text-sm text-slate-700">{analysis.breakdown.need}</p>
              </div>
           </div>
        </div>
      )}

      {/* Actions - Only if Expanded */}
      {isOpen && analysis.suggestedActions && analysis.suggestedActions.length > 0 && (
         <div className="p-4 border-t border-slate-100 bg-white">
            <div className="flex flex-wrap gap-2">
              {analysis.suggestedActions.map((action, i) => (
                <button key={i} className="px-4 py-1.5 bg-neuro-50 text-neuro-700 text-xs rounded-full border border-neuro-100 hover:bg-neuro-100 transition-colors">
                  {action}
                </button>
              ))}
            </div>
         </div>
      )}
    </div>
  );
};