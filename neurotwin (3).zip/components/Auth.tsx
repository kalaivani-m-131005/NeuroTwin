import React, { useState } from 'react';
import { View } from '../types';
import { Heart, Mail, Lock, User, ArrowRight } from 'lucide-react';

interface AuthProps {
  setView: (view: View) => void;
  onLogin: (name: string, email: string) => void;
}

export const Login: React.FC<AuthProps> = ({ setView, onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login
    if (email && password) {
      onLogin("Friend", email);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md border border-slate-100">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-neuro-100 p-3 rounded-full mb-4">
            <Heart className="w-8 h-8 text-neuro-500 fill-neuro-500" />
          </div>
          <h1 className="text-2xl font-semibold text-slate-800">Welcome Back</h1>
          <p className="text-slate-500 text-sm mt-1">Your safe space is waiting.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Mail className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
            <input
              type="email"
              placeholder="Email"
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700 transition-all"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
            <input
              type="password"
              placeholder="Password"
              className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700 transition-all"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-neuro-600 hover:bg-neuro-700 text-white font-medium py-3.5 rounded-xl shadow-md shadow-neuro-200 transition-all transform active:scale-[0.98] mt-4"
          >
            Sign In
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-slate-500 text-sm">
            New here?{' '}
            <button onClick={() => setView(View.Signup)} className="text-neuro-600 font-medium hover:underline">
              Create an account
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export const Signup: React.FC<AuthProps> = ({ setView, onLogin }) => {
  const [step, setStep] = useState<'details' | 'verify'>('details');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email && password) {
      setStep('verify');
    }
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate verification
    onLogin(name, email);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="bg-white p-8 rounded-3xl shadow-xl w-full max-w-md border border-slate-100">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-neuro-100 p-3 rounded-full mb-4">
            <User className="w-8 h-8 text-neuro-500" />
          </div>
          <h1 className="text-2xl font-semibold text-slate-800">
            {step === 'details' ? 'Join NeuroTwin' : 'Check Your Email'}
          </h1>
          <p className="text-slate-500 text-sm mt-1">
            {step === 'details' ? 'Create your personal sanctuary.' : 'We sent a 4-digit code to your email.'}
          </p>
        </div>

        {step === 'details' ? (
          <form onSubmit={handleSignup} className="space-y-4">
            <div className="relative">
              <User className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="What should we call you?"
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700 transition-all"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="relative">
              <Mail className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
              <input
                type="email"
                placeholder="Email"
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700 transition-all"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
              <input
                type="password"
                placeholder="Password"
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700 transition-all"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <button
              type="submit"
              className="w-full bg-neuro-600 hover:bg-neuro-700 text-white font-medium py-3.5 rounded-xl shadow-md shadow-neuro-200 transition-all mt-4 flex items-center justify-center gap-2"
            >
              Continue <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerify} className="space-y-4">
             <input
              type="text"
              placeholder="Enter Code (e.g. 1234)"
              className="w-full text-center text-2xl tracking-widest py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700 transition-all"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              maxLength={4}
              required
            />
            <button
              type="submit"
              className="w-full bg-neuro-600 hover:bg-neuro-700 text-white font-medium py-3.5 rounded-xl shadow-md shadow-neuro-200 transition-all mt-4"
            >
              Verify & Start
            </button>
            <button 
                type="button" 
                onClick={() => setStep('details')} 
                className="w-full text-slate-400 text-sm mt-2 hover:text-neuro-600"
            >
                Back
            </button>
          </form>
        )}

        {step === 'details' && (
          <div className="mt-6 text-center">
            <p className="text-slate-500 text-sm">
              Already have an account?{' '}
              <button onClick={() => setView(View.Login)} className="text-neuro-600 font-medium hover:underline">
                Log in
              </button>
            </p>
          </div>
        )}
      </div>
    </div>
  );
};