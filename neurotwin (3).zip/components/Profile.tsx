import React, { useState } from 'react';
import { UserProfile, Sender } from '../types';
import { ArrowLeft, LogOut, Calendar, Activity, MessageSquare, Download } from 'lucide-react';

interface ProfileProps {
  user: UserProfile | null;
  onBack: () => void;
  onLogout: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ user, onBack, onLogout }) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  if (!user) return null;

  const filteredMessages = user.chatHistory ? user.chatHistory.filter(msg => {
    if (!startDate && !endDate) return false;
    
    const msgDateStr = new Date(msg.timestamp).toLocaleDateString('en-CA'); // YYYY-MM-DD format
    
    const isAfterStart = !startDate || msgDateStr >= startDate;
    const isBeforeEnd = !endDate || msgDateStr <= endDate;

    return isAfterStart && isBeforeEnd;
  }) : [];

  const handleDownloadHistory = () => {
    if (!user.chatHistory || user.chatHistory.length === 0) return;

    const historyText = user.chatHistory.map(msg => {
        const date = new Date(msg.timestamp).toLocaleString();
        const role = msg.sender === Sender.User ? 'You' : 'NeuroTwin';
        return `[${date}] ${role}:\n${msg.text}\n`;
    }).join('\n-------------------\n');

    const blob = new Blob([historyText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `neurotwin-chat-history-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <div className="bg-white shadow-sm px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <button onClick={onBack} className="p-2 rounded-full hover:bg-slate-100 text-slate-600 transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-lg font-semibold text-slate-800">Your Profile</h1>
        <div className="w-10" /> {/* Spacer for centering */}
      </div>

      <div className="p-6 max-w-2xl mx-auto w-full space-y-8">
        {/* Header Card */}
        <div className="bg-white rounded-3xl p-8 shadow-sm text-center">
          <div className="w-20 h-20 bg-neuro-100 rounded-full mx-auto flex items-center justify-center text-2xl font-bold text-neuro-600 mb-4">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <h2 className="text-2xl font-bold text-slate-800">{user.name}</h2>
          <p className="text-slate-500">{user.email}</p>
          <div className="text-xs text-slate-400 mt-2">Member since {new Date(user.joinedAt).toLocaleDateString()}</div>
          
          <button 
            onClick={onLogout}
            className="mt-6 flex items-center justify-center gap-2 mx-auto px-6 py-2.5 rounded-full bg-red-50 text-red-500 hover:bg-red-100 transition-colors font-medium text-sm"
          >
            <LogOut className="w-4 h-4" /> Sign Out
          </button>
        </div>

        {/* Emotional Journey */}
        <div>
             <h3 className="text-lg font-semibold text-slate-700 mb-4 flex items-center gap-2">
                 <Activity className="w-5 h-5 text-neuro-500" /> Emotional Journey
             </h3>
        
            {user.moodLogs.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 text-center text-slate-400 border border-slate-100">
                <Activity className="w-10 h-10 mx-auto mb-3 opacity-50" />
                <p>No emotional logs yet. Start chatting!</p>
            </div>
            ) : (
            <div className="grid gap-4 max-h-60 overflow-y-auto pr-2">
                {user.moodLogs.slice().reverse().map((log, idx) => (
                <div key={idx} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-50 flex items-center justify-between">
                    <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        log.intensity > 0.6 ? 'bg-neuro-100 text-neuro-600' : 'bg-slate-100 text-slate-500'
                    }`}>
                        <span className="font-bold text-sm">{(log.intensity * 10).toFixed(0)}</span>
                    </div>
                    <div>
                        <p className="font-medium text-slate-800 capitalize">{log.emotion}</p>
                        <p className="text-xs text-slate-400 flex items-center gap-1 mt-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(log.date).toLocaleString()}
                        </p>
                    </div>
                    </div>
                    {log.intensity > 0.7 && (
                    <span className="px-3 py-1 bg-yellow-50 text-yellow-600 text-xs rounded-full font-medium">High Intensity</span>
                    )}
                </div>
                ))}
            </div>
            )}
        </div>

         {/* Chat Archive Search */}
         <div>
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-slate-700 flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-neuro-500" /> Chat Archive
                </h3>
                {user.chatHistory && user.chatHistory.length > 0 && (
                    <button 
                        onClick={handleDownloadHistory}
                        className="flex items-center gap-1.5 text-xs font-medium text-neuro-600 bg-neuro-50 px-3 py-1.5 rounded-full hover:bg-neuro-100 transition-colors"
                    >
                        <Download className="w-3.5 h-3.5" /> Download All
                    </button>
                )}
            </div>
            
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                <div className="mb-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">From</label>
                        <div className="relative">
                            <Calendar className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
                            <input 
                                type="date" 
                                className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700"
                                value={startDate}
                                onChange={(e) => setStartDate(e.target.value)}
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-slate-700 mb-2">To</label>
                        <div className="relative">
                            <Calendar className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
                             <input 
                                type="date" 
                                className="w-full pl-12 pr-4 py-3 rounded-xl bg-slate-50 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-neuro-300 text-slate-700"
                                value={endDate}
                                onChange={(e) => setEndDate(e.target.value)}
                            />
                        </div>
                    </div>
                </div>

                <div className="space-y-4">
                    {!startDate && !endDate ? (
                        <div className="text-center py-8 text-slate-400 text-sm">
                            Select a date range to see your conversation history.
                        </div>
                    ) : filteredMessages.length === 0 ? (
                        <div className="text-center py-8 text-slate-400 text-sm">
                            No messages found for this period.
                        </div>
                    ) : (
                        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                            {filteredMessages.map((msg) => (
                                <div key={msg.id} className={`flex flex-col ${msg.sender === Sender.User ? 'items-end' : 'items-start'}`}>
                                    <div className={`max-w-[90%] px-4 py-2 rounded-2xl text-sm ${
                                        msg.sender === Sender.User 
                                            ? 'bg-neuro-600 text-white rounded-tr-none' 
                                            : 'bg-slate-100 text-slate-700 rounded-tl-none'
                                    }`}>
                                        {msg.text}
                                    </div>
                                    <span className="text-[10px] text-slate-400 mt-1">
                                        {new Date(msg.timestamp).toLocaleString()}
                                    </span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>
         </div>
      </div>
    </div>
  );
};