import React, { useState, useRef, useEffect } from 'react';
import { Message, Sender, Analysis } from '../types';
import { generateResponse } from '../services/geminiService';
import { AnalysisWidget } from './AnalysisWidget';
import { Send, User, Loader2, Mic, Bookmark, X, Check } from 'lucide-react';

interface ChatInterfaceProps {
  initialMessages: Message[];
  onUpdateMessages: (messages: Message[]) => void;
  onSaveMood: (emotion: string, intensity: number) => void;
  onOpenProfile: () => void;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ initialMessages, onUpdateMessages, onSaveMood, onOpenProfile }) => {
  const [messages, setMessages] = useState<Message[]>(() => {
    if (initialMessages && initialMessages.length > 0) return initialMessages;
    return [{
      id: '1',
      sender: Sender.AI,
      text: "Hi there. I'm NeuroTwin. I'm here as a friend to listen. How are you feeling right now?",
      timestamp: Date.now(),
    }];
  });
  
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  
  // Editing state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    // Use a small timeout to ensure DOM layout is complete (including child components)
    const timeout = setTimeout(scrollToBottom, 100);
    return () => clearTimeout(timeout);
  }, [messages, editingId, isLoading]);

  // Sync initial greeting to persistence if history was empty
  useEffect(() => {
    if (initialMessages.length === 0 && messages.length === 1) {
        // This is likely the initial greeting
        onUpdateMessages(messages);
    }
  }, []);

  // Cleanup speech recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []);

  const toggleVoiceInput = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
      alert("Voice input is not supported in this browser.");
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    // We allow the browser to default to the user's system language for best results
    
    recognition.onstart = () => setIsListening(true);
    
    recognition.onend = () => {
      setIsListening(false);
    };
    
    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      setIsListening(false);
    };
    
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      if (transcript) {
        setInputText(prev => {
          const prefix = prev.trim().length > 0 ? ' ' : '';
          return prev + prefix + transcript;
        });
      }
    };

    recognitionRef.current = recognition;
    recognition.start();
  };

  // Helper to update state and notify parent
  const updateMessagesState = (newMessages: Message[] | ((prev: Message[]) => Message[])) => {
    setMessages(prev => {
        const updated = typeof newMessages === 'function' ? newMessages(prev) : newMessages;
        // Defer the parent update slightly to avoid potential render loop strictness, though usually safe
        setTimeout(() => onUpdateMessages(updated), 0);
        return updated;
    });
  };

  const toggleBookmark = (id: string) => {
    updateMessagesState(prev => prev.map(msg => 
      msg.id === id ? { ...msg, isBookmarked: !msg.isBookmarked } : msg
    ));
  };

  const handleEditStart = (msg: Message) => {
    setEditingId(msg.id);
    setEditContent(msg.text);
  };

  const handleEditCancel = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
    setEditContent('');
  };

  const handleEditSave = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (editContent.trim() === '') return;
    
    updateMessagesState(prev => prev.map(msg => 
      msg.id === editingId ? { ...msg, text: editContent } : msg
    ));
    setEditingId(null);
    setEditContent('');
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim() || isLoading) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: Sender.User,
      text: inputText,
      timestamp: Date.now()
    };

    updateMessagesState(prev => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      // We need the latest history including the user message for the API call
      // Since setMessages is async, we reconstruct the current state locally
      const currentHistory = [...messages, userMsg];
      
      const rawResponse = await generateResponse(currentHistory, userMsg.text);
      
      const analysis: Analysis = {
        emotion: rawResponse.emotion || "Neutral",
        intensity: rawResponse.intensity || 0,
        reason: rawResponse.reason || "",
        breakdown: rawResponse.breakdown || { thought: "", feeling: "", bodyReaction: "", need: "" },
        suggestedActions: rawResponse.suggestedActions || []
      };

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: Sender.AI,
        text: rawResponse.reply,
        timestamp: Date.now(),
        analysis: analysis
      };

      updateMessagesState(prev => [...prev, aiMsg]);
      
      // Log mood automatically
      if (analysis.emotion) {
        onSaveMood(analysis.emotion, analysis.intensity);
      }

    } catch (err) {
      console.error("Error getting response", err);
       const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: Sender.AI,
        text: "I'm having a little trouble thinking clearly right now. Could you try again?",
        timestamp: Date.now(),
      };
      updateMessagesState(prev => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Helper to bold formatting (simple implementation)
  const renderText = (text: string) => {
    // Split by **bold** markers if the AI uses markdown, though we prompt for simple text, 
    // sometimes it might slip through. We can just render normally.
    return text; 
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50">
      {/* Header */}
      <div className="h-16 bg-white/80 backdrop-blur-md border-b border-slate-200 flex items-center justify-between px-4 sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-2">
           <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-neuro-300 to-neuro-500 flex items-center justify-center text-white font-bold text-sm">
             NT
           </div>
           <span className="font-semibold text-slate-700 tracking-tight">NeuroTwin</span>
        </div>
        <button onClick={onOpenProfile} className="p-2 rounded-full hover:bg-slate-100 text-slate-500 transition-colors">
          <User className="w-6 h-6" />
        </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.sender === Sender.User ? 'items-end' : 'items-start'} animate-fade-in`}>
            {/* Bubble or Edit Form */}
            {msg.id === editingId && msg.sender === Sender.User ? (
               <div className={`max-w-[90%] sm:max-w-[80%] w-full px-4 py-3 rounded-2xl rounded-tr-none shadow-sm bg-neuro-600 text-white flex flex-col gap-2`}>
                  <textarea 
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      className="bg-white/10 text-white placeholder-white/50 w-full p-2 rounded-md focus:outline-none focus:ring-2 focus:ring-white/30 resize-none text-[15px]"
                      rows={Math.max(2, Math.ceil(editContent.length / 40))}
                      autoFocus
                      onClick={(e) => e.stopPropagation()}
                  />
                  <div className="flex justify-end gap-2">
                      <button onClick={handleEditCancel} className="p-1 hover:bg-white/20 rounded-full transition-colors" title="Cancel">
                          <X className="w-4 h-4" />
                      </button>
                      <button onClick={handleEditSave} className="p-1 hover:bg-white/20 rounded-full transition-colors" title="Save">
                          <Check className="w-4 h-4" />
                      </button>
                  </div>
               </div>
            ) : (
              <div 
                onClick={() => msg.sender === Sender.User && handleEditStart(msg)}
                className={`max-w-[90%] sm:max-w-[80%] px-5 py-3.5 rounded-2xl shadow-sm text-[15px] leading-relaxed whitespace-pre-wrap relative transition-colors duration-300
                  ${msg.sender === Sender.User 
                    ? 'bg-neuro-600 text-white rounded-tr-none cursor-pointer hover:bg-neuro-700' 
                    : msg.isBookmarked
                      ? 'bg-amber-50/50 text-slate-800 border border-amber-200 rounded-tl-none'
                      : 'bg-white text-slate-700 border border-slate-100 rounded-tl-none'
                  }`}
                title={msg.sender === Sender.User ? "Click to edit" : ""}
              >
                {renderText(msg.text)}
                {msg.isBookmarked && (
                  <div className="absolute -top-2 -right-2 bg-amber-100 text-amber-600 p-1 rounded-full border border-amber-200 shadow-sm">
                      <Bookmark className="w-3 h-3 fill-current" />
                  </div>
                )}
              </div>
            )}

            {/* Save Action for High Intensity */}
            {msg.sender === Sender.AI && msg.analysis && msg.analysis.intensity >= 0.7 && (
                <div className="mt-1.5 mb-1 flex items-center gap-2">
                    <button
                    onClick={() => toggleBookmark(msg.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                        msg.isBookmarked 
                        ? 'bg-amber-50 text-amber-700 border-amber-200 shadow-sm' 
                        : 'bg-transparent text-slate-400 border-transparent hover:bg-slate-100'
                    }`}
                    >
                    <Bookmark className={`w-3.5 h-3.5 ${msg.isBookmarked ? 'fill-current' : ''}`} />
                    {msg.isBookmarked ? 'Saved' : 'Save for later'}
                    </button>
                </div>
            )}

            {/* AI Analysis Widget (Only for AI messages that have it) */}
            {msg.sender === Sender.AI && msg.analysis && (
              <div className="w-full max-w-[90%] sm:max-w-[80%] mt-1">
                <AnalysisWidget analysis={msg.analysis} />
              </div>
            )}
            
            {/* Timestamp */}
            {msg.id !== editingId && (
              <span className="text-[10px] text-slate-400 mt-1 px-1">
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                {msg.sender === Sender.User && <span className="ml-1 opacity-60">(Click to edit)</span>}
              </span>
            )}
          </div>
        ))}
        {isLoading && (
           <div className="flex flex-col items-start animate-fade-in">
              <div className="bg-white px-4 py-3 rounded-2xl rounded-tl-none border border-slate-100 shadow-sm flex items-center gap-2">
                 <Loader2 className="w-4 h-4 text-neuro-400 animate-spin" />
                 <span className="text-slate-400 text-sm">Thinking...</span>
              </div>
           </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-white border-t border-slate-100 safe-area-pb">
        <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto relative flex items-center gap-2">
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={isListening ? "Listening..." : "Type here..."}
              className={`w-full bg-slate-50 border text-slate-800 rounded-full pl-6 pr-12 py-3.5 focus:outline-none focus:ring-2 transition-all placeholder-slate-400
                ${isListening ? 'border-neuro-400 ring-2 ring-neuro-100' : 'border-slate-200 focus:ring-neuro-200'}
              `}
              disabled={isLoading}
            />
            <button
              type="button"
              onClick={toggleVoiceInput}
              className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-2 rounded-full transition-all
                ${isListening 
                  ? 'bg-red-50 text-red-500 animate-pulse' 
                  : 'text-slate-400 hover:text-neuro-600 hover:bg-slate-100'
                }
              `}
              title={isListening ? "Stop listening" : "Start voice input"}
            >
              <Mic className="w-5 h-5" />
            </button>
          </div>
          
          <button 
            type="submit"
            disabled={!inputText.trim() || isLoading}
            className={`p-3.5 rounded-full flex-shrink-0 transition-all duration-200 ${
              inputText.trim() && !isLoading
               ? 'bg-neuro-600 text-white shadow-md hover:bg-neuro-700 transform hover:scale-105' 
               : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
          >
            <Send className="w-5 h-5 ml-0.5" />
          </button>
        </form>
      </div>
    </div>
  );
};