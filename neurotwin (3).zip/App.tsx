import React, { useState, useEffect } from 'react';
import { AuthState, View, UserProfile, Message } from './types';
import { Login, Signup } from './components/Auth';
import { ChatInterface } from './components/ChatInterface';
import { Profile } from './components/Profile';

const App: React.FC = () => {
  // Check local storage for fake session
  const [authState, setAuthState] = useState<AuthState>(() => {
    const stored = localStorage.getItem('neuro_user');
    if (stored) {
        const parsedUser = JSON.parse(stored);
        // Ensure chatHistory exists for migration
        if (!parsedUser.chatHistory) {
            parsedUser.chatHistory = [];
        }
        return { isLoggedIn: true, user: parsedUser };
    }
    return { isLoggedIn: false, user: null };
  });

  const [currentView, setCurrentView] = useState<View>(authState.isLoggedIn ? View.Chat : View.Login);

  const handleLogin = (name: string, email: string) => {
    const newUser: UserProfile = {
      name,
      email,
      joinedAt: new Date().toISOString(),
      moodLogs: [],
      chatHistory: []
    };
    
    // Check if user exists to preserve logs, otherwise create new
    const stored = localStorage.getItem('neuro_user');
    let userToSave = newUser;

    if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.email === email) {
            userToSave = {
                ...parsed,
                chatHistory: parsed.chatHistory || []
            };
        }
    }

    localStorage.setItem('neuro_user', JSON.stringify(userToSave));
    setAuthState({ isLoggedIn: true, user: userToSave });
    setCurrentView(View.Chat);
  };

  const handleLogout = () => {
    localStorage.removeItem('neuro_user');
    setAuthState({ isLoggedIn: false, user: null });
    setCurrentView(View.Login);
  };

  const handleSaveMood = (emotion: string, intensity: number) => {
    if (!authState.user) return;
    
    const updatedUser = {
      ...authState.user,
      moodLogs: [
        ...authState.user.moodLogs,
        { date: new Date().toISOString(), emotion, intensity }
      ]
    };
    
    setAuthState({ ...authState, user: updatedUser });
    localStorage.setItem('neuro_user', JSON.stringify(updatedUser));
  };

  const handleUpdateChatHistory = (messages: Message[]) => {
    if (!authState.user) return;
    
    const updatedUser = { ...authState.user, chatHistory: messages };
    
    setAuthState(prev => {
        if (!prev.user) return prev;
        return { ...prev, user: { ...prev.user, chatHistory: messages } };
    });
    localStorage.setItem('neuro_user', JSON.stringify(updatedUser));
  };

  // Routing Logic
  const renderView = () => {
    switch (currentView) {
      case View.Login:
        return <Login setView={setCurrentView} onLogin={handleLogin} />;
      case View.Signup:
        return <Signup setView={setCurrentView} onLogin={handleLogin} />;
      case View.Chat:
        return authState.isLoggedIn ? (
          <ChatInterface 
            initialMessages={authState.user?.chatHistory || []}
            onUpdateMessages={handleUpdateChatHistory}
            onSaveMood={handleSaveMood} 
            onOpenProfile={() => setCurrentView(View.Profile)} 
          />
        ) : (
          <Login setView={setCurrentView} onLogin={handleLogin} />
        );
      case View.Profile:
        return authState.isLoggedIn ? (
          <Profile 
            user={authState.user} 
            onBack={() => setCurrentView(View.Chat)} 
            onLogout={handleLogout} 
          />
        ) : (
          <Login setView={setCurrentView} onLogin={handleLogin} />
        );
      default:
        return <Login setView={setCurrentView} onLogin={handleLogin} />;
    }
  };

  return (
    <div className="antialiased text-slate-800 bg-slate-50 min-h-screen">
      {renderView()}
    </div>
  );
};

export default App;